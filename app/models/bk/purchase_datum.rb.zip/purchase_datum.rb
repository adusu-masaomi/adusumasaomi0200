class PurchaseDatum < ActiveRecord::Base
	has_many :UnitMaster  # <== 関係を追記
	has_many :MakerMaster
	#has_many :MaterialMaster
	has_many :material_masters, :foreign_key => "id"
    #belongs_to :material_masters
	#has_many :material_masters
	
	#has_many :material_masters, ->(o) { where material_id: o.id }
	
	#belongs_to :material_master
	
	has_many :PurchaseUnitPrice
	
	def self.sumprice  
    	sum(:purchase_amount)
    	#User.sumでもかまいません
    	#カラム名(フィールド名)は大文字使ってもいいですが、普通小文字の方がよいです
  	end
	
    belongs_to :purchase_order_datum , :class_name => 'PurchaseOrderDatum',  :foreign_key => "purchase_order_datum_id"
	#belongs_to :purchase_order_datum
	
	belongs_to :construction_datum
	#test del
	#delegate :purchase_order_datum, to: :construction_datum
    
	has_many :SupplierMaster
	
	belongs_to :CustomerMaster,  :foreign_key => "customer_id"
	
	scope :with_purchase_order, -> (purchase_order_data_construction_datum_id=1) { joins(:purchase_order_datum).where("purchase_order_data.construction_datum_id = ?", purchase_order_data_construction_datum_id )}
    scope :with_construction, -> (purchase_order_data_construction_datum_id=1) { joins(:construction_datum).where("construction_data.id = ?", purchase_order_data_construction_datum_id )}
	scope :with_customer, -> (construction_datum_customer_id=1){joins(:construction_datum).where("construction_data.customer_id = ?", construction_datum_customer_id )}
	
	#test
	scope :with_material, -> (material_id=1) { joins(:material_masters).where("material_masters.id = ?", material_id  ) }
	
	#scope :with_purchase_order_join,
	#   lambda { |purchase_order_datum|
    #   where(purchase_order_datum_construction_id: purchase_order_data.construction_id)
	#}
	
	def self.ransackable_scopes(auth_object=nil)
  		[:with_purchase_order, :with_customer, :with_construction, :with_material]
	end
	
	def self.to_csv(options = {})
      CSV.generate do |csv|
        # column_namesはカラム名を配列で返す
        # 例: ["id", "name", "price", "released_on", ...]
		#@purchase_data = PurchaseDatum.includes(:purchase_order_datum)
        csv << column_names
        all.each do |purchase_datum|
          # attributes はカラム名と値のハッシュを返す
          # 例: {"id"=>1, "name"=>"レコーダー", "price"=>3000, ... }
          # valudes_at はハッシュから引数で指定したキーに対応する値を取り出し、配列にして返す
          # 下の行は最終的に column_namesで指定したvalue値の配列を返す
          # csv << purchase_datum.attributes.values_at(*column_names)
          csv << purchase_datum.csv_column_values
		end
      end
    end
	
	def csv_column_values
      [purchase_date, purchase_order_datum.purchase_order_code, construction_datum.construction_code,construction_datum.construction_name, MakerMaster.maker_name, material_name]
    end
end
